package myspring.demo;

import myspring.struct.Linkman;
import myspring.struct.Table;
import myspring.struct.changeTable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class addController {
    //点击“增加”按钮，会出发add选项
    @PostMapping("/add")
    public String showAdd(Linkman linkman, Model model){
        //建立一个联系人模型，交给add.html渲染处理
        model.addAttribute("linkman",linkman);
        return "add";
    }
    //add.html点击提交，进行检查
    @PostMapping("/checkadd")
    public String checkAdd(Linkman linkman, HttpServletRequest request, Model model){
        Table t = (Table)request.getSession().getAttribute("table");
        boolean isvalid = changeTable.checkAdd(t,linkman);
        if(isvalid){
            t.getTable().addElement(linkman);
            return "redirect:/list";
        }
        else{
            linkman.setMessage("联系人已存在");
            linkman.setName("");
            return showAdd(linkman,model);
        }
    }
}
