package myspring.demo;

import myspring.struct.Table;
import myspring.struct.changeTable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class delController {
    //从list.html中点击删除
    @PostMapping("/del")
    public String DeleteLinkman(@ModelAttribute(value="row")Integer row, HttpServletRequest request){
        Table t = (Table)request.getSession().getAttribute("table");
        changeTable.deleteElement(t,row);
        return "redirect:/list";
    }
}
