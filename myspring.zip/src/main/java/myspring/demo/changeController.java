package myspring.demo;

import myspring.struct.Linkman;
import myspring.struct.Table;
import myspring.struct.changeTable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//访问添加页面、判断修改状态页面，在Session中创建和add.html传递数据的类linkman
@Controller
public class changeController {
    //通过导航栏直接访问
    @GetMapping({"add","/checkadd","/change","/checkchange","/del"})
    public String goBack(HttpServletRequest request){
        Object flag = request.getSession().getAttribute("login");
        if(null != flag){
            HttpSession session = request.getSession();
            if(null == session.getAttribute("table")){
                Table table = new Table();
                session.setAttribute("table",table);
            }
            return "redirect:/list";
        }
        else
            return "redirect:/login";
    }
    //点击"修改"按钮
    @PostMapping("/change")
    public String showChange(@ModelAttribute(value="row")Integer row, HttpServletRequest request, Model model){
        //修改会将当前列表行传过去
        Table t = (Table)request.getSession().getAttribute("table");
        //利用这一行列表实例化一个联系人对象
        Linkman linkman = t.getTable().elementAt(row);
        //将联系人对象传给change.html以便修改
        model.addAttribute("linkman",linkman);
        return "change";
    }
    //在change.html点击提交
    @PostMapping("/checkchange")
    public String checkChange(Linkman linkman, HttpServletRequest request){
        Table t = (Table)request.getSession().getAttribute("table");
        changeTable.changeElement(t,linkman);
        return "redirect:/list";
    }
}