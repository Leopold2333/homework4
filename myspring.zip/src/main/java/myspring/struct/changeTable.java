package myspring.struct;

import java.util.Vector;

public class changeTable {
    //外部引用
    public static boolean checkAdd(Table table, Linkman linkman){
        boolean isvalid=true;
        Vector<Linkman> list = table.getTable();
        for(int i=0; i<list.size() && isvalid; i++){
            if(list.elementAt(i).getName().equals(linkman.getName()))
                isvalid=false;
        }
        return isvalid;
    }
    public static void changeElement(Table table, Linkman linkman){
        int index = -1;
        Vector<Linkman> list = table.getTable();
        for(int i=0; i<list.size() && -1==index; i++){
            //根据姓名匹配要修改的对象
            if(list.elementAt(i).getName().equals(linkman.getName()))
                index = i;
        }
        //根据匹配到的目标，用linkman覆盖修改该行list数据
        if(index!=-1){
            list.set(index,linkman);
        }
    }
    //传进来的index指示list中的元素位置，移除列表的该项即可
    public static void deleteElement(Table table, int index){
        table.getTable().remove(index);
    }
}
