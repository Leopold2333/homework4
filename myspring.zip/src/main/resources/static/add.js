function check(id)
{
    var elem = document.getElementById(id);     //获取需要检查的标签元素
    var content = elem.value;                   //获取该标签内容
    var temp = null;
    var pattern = elem.pattern;                 //获取该标签已经设置好的正则匹配规则
    var regex = new RegExp('^' + pattern + '$'); //将pattern加上头尾标识
    var match = regex.exec(content);              //进行正则匹配

    if (id == 'linker_Name')
        temp = document.getElementById('pname');
    else if (id == 'linker_Phone')
        temp = document.getElementById('pphone');
    else if (id == 'linker_Email')
        temp = document.getElementById('pemail');
    else if (id == 'linker_Address')
        temp = document.getElementById('paddress');
    else if (id == 'linker_QQ')
        temp = document.getElementById('pqq');
    //内容变为空
    if ("" == content && temp!=null)
    {
        temp.innerHTML = "?";
        temp.style.color = "#FFA500";
    }
    //匹配成功
    else if (null != match && temp!=null)
    {
        temp.innerHTML = "√";
        temp.style.color = "#00FF00";
    }
    //匹配失败
    else if (null == match && temp!=null)
    {
        temp.innerHTML = "×";
        temp.style.color = "#FF0000";
    }
}